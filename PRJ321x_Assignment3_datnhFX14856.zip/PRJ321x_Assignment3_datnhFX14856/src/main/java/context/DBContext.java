/**
 * Copyright(C) 
 * DBContext.java Sep 1, 2022 nguyenhaidat
 */
package context;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author nguyen hai dat
 *
 */
public class DBContext {
	protected static Connection conn = null;
	private final String driver = "com.mysql.jdbc.Driver";
	private final String url = "jdbc:mysql://localhost:3306/ShoppingDB";
	private final String user_name = "root";
	private final String pass_word = "datnguyenhai5";

	public Connection getConnection() throws SQLException, ClassNotFoundException {
		Class.forName(driver);
		return DriverManager.getConnection(url, user_name, pass_word);
	}
	public void closeConnection() throws SQLException {
		try {
			if (conn != null && conn.isClosed()) {
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}	
	}
}
