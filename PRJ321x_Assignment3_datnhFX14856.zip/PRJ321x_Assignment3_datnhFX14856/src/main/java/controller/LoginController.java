package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Account;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			String regexMail = "^[A-Z0-9_a-z]+@[A-Z0-9\\.a-z]+\\.[A-Za-z]{2,6}$";
			String regex = "[a-zA-Z0-9_!@#$%^&*]+";
			// COLLECT DATA FROM LOGIN FORM
			String user = request.getParameter("username");
			String password = request.getParameter("password");
			String action = request.getParameter("action");
			Account account = new Account();
			account.setName(user);
			account.setPassword(password);
			HttpSession session = request.getSession(true);
			String message = "";
			session.setAttribute("error", message);
			// read from web.xml
			String checkUser = getServletContext().getInitParameter("username");
			String checkPass = getServletContext().getInitParameter("password");
			if (!password.matches(regex) || !user.matches(regexMail)) {
				message = "invalid syntax";
				session.setAttribute("error", message);
				response.sendRedirect("login.jsp");
			}
			else if (user != null && user.equals(checkUser) && password.equals(checkPass)) {
				session.setAttribute("user", user);
				response.sendRedirect("index.jsp");
			} else {
				message = "wrong username or password";
				session.setAttribute("error", message);
				response.sendRedirect("login.jsp"); 
			}

		} catch (NullPointerException e) {
			// TODO: handle exception
			RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
			rd.forward(request, response);
		} catch (Exception e) {

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
