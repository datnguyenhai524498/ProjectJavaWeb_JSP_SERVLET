/**
 * Copyright(C) 
 * Cart.java Sep 1, 2022 nguyenhaidat
 */
package model;

import java.util.ArrayList;
import java.util.List;

/**
 * @author nguyen hai dat
 *
 */
public class Cart {
	private List<Product> items;
	public Cart() {
		items = new ArrayList<>();
	}
	// add new product to cart
	public void add(Product ci) {
		for(Product p : items) {
			if(ci.getId() == p.getId()) {
				p.setId(p.getId() + 1);
				return;
			}
		}
		items.add(ci);
	}
	//remove a product to cart
	public void remove(int id) {
		for(Product p : items) {
			if(p.getId() == id) {
				items.remove(p);
				return;
			}
		}
	}
	// return amount of cart
	public double getAmount() {
		double s = 0;
		for(Product p : items) {
			s += p.getPrice() * p.getNumber();
			
		}
		return Math.round(s*100.0) / 100.0;
	}
	
	// return list product
	public List<Product> getItems() {
		return items;
	}
}
