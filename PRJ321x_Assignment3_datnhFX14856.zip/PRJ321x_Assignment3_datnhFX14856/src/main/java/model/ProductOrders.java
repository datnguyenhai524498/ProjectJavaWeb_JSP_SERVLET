/**
 * Copyright(C) 
 * ProductOrders.java Sep 1, 2022 nguyenhaidat
 */
package model;

/**
 * @author nguyen hai dat
 *
 */
public class ProductOrders {
	private int orderId;
	private int productId;
	private int amountProduct;
	private String nameProduct;
	public ProductOrders(int orderId, int productId, int amountProduct, String nameProduct) {
		super();
		this.orderId = orderId;
		this.productId = productId;
		this.amountProduct = amountProduct;
		this.nameProduct = nameProduct;
	}
	/**
	 * @return the orderId
	 */
	public int getOrderId() {
		return orderId;
	}
	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	/**
	 * @return the productId
	 */
	public int getProductId() {
		return productId;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(int productId) {
		this.productId = productId;
	}
	/**
	 * @return the amountProduct
	 */
	public int getAmountProduct() {
		return amountProduct;
	}
	/**
	 * @param amountProduct the amountProduct to set
	 */
	public void setAmountProduct(int amountProduct) {
		this.amountProduct = amountProduct;
	}
	/**
	 * @return the nameProduct
	 */
	public String getNameProduct() {
		return nameProduct;
	}
	/**
	 * @param nameProduct the nameProduct to set
	 */
	public void setNameProduct(String nameProduct) {
		this.nameProduct = nameProduct;
	}
	
}
