/**
 * Copyright(C) 
 * Test.java Sep 1, 2022 nguyenhaidat
 */
package dao;

import java.sql.SQLException;
import java.util.List;

import model.Orders;
import model.Product;

/**
 * @author nguyen hai dat
 *
 */
public class Test {

	/**
	 * @param args
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		//ListProductDAO ld = new ListProductDAO();
		//Product p = new Product();
		/*try {
			List<Product> list = ld.search("");
			for(Product p : list) {
				System.out.println("Name: ");
				System.out.println(p);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//Product p = new Product();
		//ld.getProduct("3");
		//System.out.println(ld.getProduct("3")); */
		OrdersDAO o = new OrdersDAO();
		Orders order = new Orders();
		o.insertOrder(order, null);
	}
}
