/**
 * Copyright(C) 
 * ListProductDAO.java Sep 1, 2022 nguyenhaidat
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import context.DBContext;
import model.Product;

/**
 * @author nguyen hai dat
 *
 */
public class ListProductDAO {
	
	public List<Product> search(String character) throws ClassNotFoundException, SQLException {
		Connection conn = null;
		DBContext context = new DBContext();
		List<Product> list = new ArrayList<>();
		
		String query = "Select * from Products where product_name like ?";
		conn = context.getConnection();
		PreparedStatement ps = conn.prepareStatement(query);
		ps.setString(1,"%" + character + "%");
		
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			Product product = new Product();
			product.setId(rs.getInt(1));
			product.setName(rs.getString(2));
			product.setDescription(rs.getString(3));
			product.setPrice(rs.getFloat(4));
			product.setSrc(rs.getString(5));
			product.setType(rs.getString(6));
			product.setBrand(rs.getString(7)); 
			list.add(product);
		}
		return list;
		
	}
	public Product getProduct(String character) throws SQLException, ClassNotFoundException {
		Connection conn = null;
		int id = Integer.parseInt(character);
		DBContext context = new DBContext();
		String query = "select * from Products where product_id = ?";
		conn = context.getConnection();
		Product product = new Product();
		PreparedStatement ps = conn.prepareStatement(query);
		ps.setLong(1,id);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			product.setId(rs.getInt(1));
			product.setName(rs.getString(2));
			product.setDescription(rs.getString(3));
			product.setPrice(rs.getFloat(4));
			product.setSrc(rs.getString(5));
			product.setType(rs.getString(6));
			product.setBrand(rs.getString(7)); 
		}
		return product;
	}
}
