/**
 * Copyright(C) 
 * OrdersDAO.java Sep 1, 2022 nguyenhaidat
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import context.DBContext;
import model.Cart;
import model.Orders;
import model.Product;

/**
 * @author nguyen hai dat
 *
 */
public class OrdersDAO {
	public void insertOrder(Orders order, Cart cart) throws ClassNotFoundException, SQLException {
		String sql = "insert into Orders(user_mail,order_status,order_discount_code,order_date,order_address) values (?,1,?,?,?)";
		Connection conn = null;
		DBContext context = new DBContext();
		LocalDate curDate = java.time.LocalDate.now();
		String date = curDate.toString();
		conn = context.getConnection();
		PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
		ps.setString(1, order.getUserMail());
		ps.setString(2, order.getDiscount());
		ps.setString(3, date);
		ps.setString(4, order.getAddress());
		int affectedrow = ps.executeUpdate();
		if(affectedrow == 0) {
			throw new SQLException("Creating user failed, no rows affected.");
		} 
		try(ResultSet rs = ps.getGeneratedKeys()) {
			if(rs.next()) {
				order.setOrderId(rs.getInt(1));
			} else {
				throw new SQLException("Creating user failed, no ID affected.");
			}
		}
		String sql2 = "select order_id from Orders order by order_id desc";
		PreparedStatement ps2 = conn.prepareStatement(sql2);
		ResultSet rs = ps2.executeQuery();
		if(rs.next()) {
			int oid = rs.getInt(1);
			for(Product p : cart.getItems()) {
				String sql3 = "insert into Orders_detail(order_id,product_id) values (?,?)";
				PreparedStatement ps3 = conn.prepareStatement(sql3);
				ps3.setInt(1, oid);
				ps3.setInt(2, p.getId());
				ps3.executeUpdate();
			}
		}
		
	}
}
